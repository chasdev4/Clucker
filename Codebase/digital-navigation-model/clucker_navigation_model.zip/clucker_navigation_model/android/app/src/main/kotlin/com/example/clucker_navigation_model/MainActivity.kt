package com.example.clucker_navigation_model

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
